# ✈ Pilot Fatigue Detection System v3.0

## What's New in v3

| Feature | v2 | v3 |
|---------|----|----|
| Face mesh | EAR points only | **Full 468-point color tessellation** |
| Iris tracking | ❌ | **✅ Real-time gaze estimation** |
| PERCLOS | ❌ | **✅ FAA gold-standard metric** |
| Microsleep | ❌ | **✅ Eyes-closed > 1.5s = instant CRITICAL** |
| Adaptive baseline | ❌ | **✅ Learns your personal EAR in 30s** |
| Start/Stop | Always on | **✅ SPACE to start/stop (use when needed)** |
| Session timer | ❌ | **✅ Color-coded 45min/90min warnings** |
| Fatigue trend | ❌ | **✅ Rising ▲ / Stable / Falling ▼** |
| Head pose widget | ❌ | **✅ Mini 3D crosshair indicator** |
| Gaze indicator | ❌ | **✅ Mini eye diagram** |
| FPS adaptive | ❌ | **✅ Auto-adjusts frame skip** |
| Mesh toggle | ❌ | **✅ M key to toggle** |

## Quick Start

```powershell
pip install -r requirements.txt
python main.py
```

Press **SPACE** to start monitoring. Press **SPACE** again to stop.

## Controls

| Key | Action |
|-----|--------|
| `SPACE` | Start / Stop monitoring |
| `Q` / `Esc` | Quit |
| `S` | Save screenshot |
| `R` | Reset all counters |
| `M` | Toggle full 468-pt mesh |
| `I` | Toggle iris tracking |

## Command Line Options

```powershell
python main.py --camera 1          # Use camera index 1
python main.py --threshold 0.45    # More sensitive
python main.py --no-mesh           # Disable mesh (better FPS)
python main.py --log --screenshots # Enable logging
python main.py --skip 1            # Process every frame (most accurate)
python main.py --skip 3            # Skip more frames (lower CPU)
```

## How the Score Works

```
Fatigue Score = 35% × Eye Score (EAR + PERCLOS)
              + 20% × Blink Rate
              + 25% × Head Pose (pitch/yaw/roll)
              + 20% × Yawn Detection
              + Session fatigue accumulation (up to +20% after 2.5h)

Microsleep override: if eyes closed > 1.5s → score ≥ 85% (CRITICAL)
```

## Alert Levels

| Score | Level | Alerts |
|-------|-------|--------|
| 0–35% | NORMAL | None |
| 35–50% | CAUTION | HUD color change |
| 50–75% | WARNING | Flash + audio + email |
| 75%+ | CRITICAL | All + microsleep banner |

## Enable Email (ATC Simulation)

Edit `utils/config.py`:
```python
email_enabled = True
email_sender  = "your@gmail.com"
email_password= "16-char-app-password"  # from myaccount.google.com/apppasswords
email_recipient = "atc@example.com"
```

## Performance Tips

- `--skip 2` (default) → ~25-30 FPS on most laptops
- `--skip 3` → lower CPU, ~20 FPS
- `--no-mesh` → removes tessellation drawing, frees ~5% CPU
- Runs entirely on CPU — no GPU needed
