"""
Audio alert — TTS voice with specific fatigue messages.
Messages:
- CAUTION: "Caution. {type} detected."
- WARNING: "Warning! Pilot fatigue detected. {type}. Please stay alert."  
- CRITICAL: "ALERT! Pilot, please wake up! {type} detected. Warning sent to ATC."
Falls back to beep if pyttsx3 not available.
"""
import threading, time, platform, os

class AudioAlert:
    def __init__(self, cfg):
        self.cfg = cfg
        self.enabled = cfg.audio_enabled
        self._sys = platform.system()
        self._last = 0.0
        self._thread = None
        self._tts_ok = self._check_tts()
        if self._tts_ok:
            print("[Audio] Voice alerts ready (TTS)")
        else:
            print("[Audio] TTS unavailable — using beep fallback")

    def _check_tts(self):
        if not self.enabled: return False
        try:
            import pyttsx3
            e = pyttsx3.init()
            e.stop()
            return True
        except Exception:
            return False

    def play(self, level="WARNING", fatigue_type="fatigue detected"):
        if not self.enabled: return
        now = time.time()
        if now - self._last < self.cfg.alert_cooldown_seconds: return
        self._last = now
        if not self._thread or not self._thread.is_alive():
            self._thread = threading.Thread(
                target=self._speak, args=(level, fatigue_type), daemon=True)
            self._thread.start()

    def _speak(self, level, fatigue_type):
        try:
            if self._tts_ok:
                self._tts(level, fatigue_type)
            elif self._sys == "Windows":
                self._beep_win(level)
            elif self._sys == "Darwin":
                self._mac(level, fatigue_type)
            else:
                self._beep_linux(level)
        except Exception as e:
            print(f"[Audio] Error: {e}")

    def _tts(self, level, fatigue_type):
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty('rate', 150)
        engine.setProperty('volume', 1.0)

        if level == "CRITICAL":
            msg = (
                f"Alert! Pilot, please wake up! "
                f"{fatigue_type} detected. "
                f"Warning has been sent to Air Traffic Control. "
                f"Immediate action required."
            )
        elif level == "WARNING":
            msg = (
                f"Warning! Pilot fatigue detected. "
                f"{fatigue_type}. "
                f"Please stay alert. Warning sent to ATC."
            )
        else:
            msg = f"Caution. {fatigue_type} detected. Please stay focused."

        engine.say(msg)
        engine.runAndWait()
        engine.stop()

    def _mac(self, level, fatigue_type):
        import subprocess
        if level == "CRITICAL":
            msg = f"Alert! Pilot please wake up! {fatigue_type}. Warning sent to ATC."
        elif level == "WARNING":
            msg = f"Warning! Pilot fatigue. {fatigue_type}. Warning sent to ATC."
        else:
            msg = f"Caution. {fatigue_type} detected."
        subprocess.run(["say", "-r", "150", msg], capture_output=True)

    def _beep_win(self, level):
        import winsound
        patterns = {
            "CAUTION":  [(440,300)],
            "WARNING":  [(660,400),(0,100),(660,400)],
            "CRITICAL": [(880,600),(0,80),(880,600),(0,80),(880,600)],
        }
        for f, d in patterns.get(level, [(440,300)]):
            winsound.Beep(f,d) if f else time.sleep(d/1000)

    def _beep_linux(self, level):
        import subprocess
        n = {"CAUTION":1,"WARNING":2,"CRITICAL":3}.get(level,1)
        for _ in range(n):
            try: subprocess.run(["beep","-f","880","-l","300"],
                                capture_output=True, timeout=2)
            except: pass
            time.sleep(0.4)
