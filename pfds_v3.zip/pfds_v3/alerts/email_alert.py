import smtplib, threading, time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dataclasses import dataclass

# ================= CONFIG =================
class Config:
    email_enabled = True
    
    # ⚠️ CHANGE THIS
    email_sender = "brishit0406@gmail.com"
    email_password = "nogv verb titz kyeu"   # <-- Put Gmail App Password here
    
    email_recipient = "brishit0406@gmail.com"
    email_smtp_host = "smtp.gmail.com"
    email_smtp_port = 587
    
    email_cooldown = 60   # seconds
    fatigue_threshold = 0.55


# ================= STATE (SIMPLIFIED) =================
@dataclass
class FatigueState:
    fatigue_score: float
    alert_level: str
    ear: float = 0.2
    perclos: float = 0.4
    blink_rate: float = 0.1
    pitch: float = 20
    yaw: float = 5
    yawn_count: int = 1
    microsleep: bool = False
    distracted: bool = False
    component_scores: dict = None


# ================= EMAIL TEMPLATE =================
TEMPLATE = """
🚨 ATC ALERT — PILOT FATIGUE DETECTED

STATUS    : {level}
TIME      : {ts}
SCORE     : {score:.1%}

----------------------------------------
EAR         : {ear:.3f}
PERCLOS     : {perclos:.1%}
Blink Rate  : {blink:.2f}/sec
Head Pitch  : {pitch:.1f}°
Yawns       : {yawns}

Microsleep  : {micro}
Distracted  : {dist}

----------------------------------------
Take immediate action!
"""

# ================= EMAIL CLASS =================
class ATCEmailAlert:
    def __init__(self, cfg):
        self.cfg = cfg
        self.enabled = cfg.email_enabled
        self._last = 0

    def send(self, state):
        if not self.enabled:
            return

        # cooldown check
        if time.time() - self._last < self.cfg.email_cooldown:
            return

        self._last = time.time()

        threading.Thread(target=self._worker, args=(state,), daemon=True).start()

    def _worker(self, state):
        try:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")

            body = TEMPLATE.format(
                level=state.alert_level,
                ts=ts,
                score=state.fatigue_score,
                ear=state.ear,
                perclos=state.perclos,
                blink=state.blink_rate,
                pitch=state.pitch,
                yawns=state.yawn_count,
                micro="YES ⚠" if state.microsleep else "No",
                dist="YES ⚠" if state.distracted else "No",
            )

            msg = MIMEMultipart()
            msg["From"] = self.cfg.email_sender
            msg["To"] = self.cfg.email_recipient
            msg["Subject"] = f"🚨 Fatigue Alert - {state.alert_level}"

            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(self.cfg.email_smtp_host, self.cfg.email_smtp_port) as server:
                server.starttls()
                server.login(self.cfg.email_sender, self.cfg.email_password)
                server.sendmail(
                    self.cfg.email_sender,
                    self.cfg.email_recipient,
                    msg.as_string()
                )

            print("✅ Email Sent Successfully!")

        except Exception as e:
            print("❌ Email Failed:", e)


# ================= MAIN TEST =================
if __name__ == "__main__":
    cfg = Config()
    email_alert = ATCEmailAlert(cfg)

    print("🚀 System Running...")

    while True:
        # 🔴 SIMULATE FATIGUE DETECTION
        state = FatigueState(
            fatigue_score=0.75,
            alert_level="CRITICAL"
        )

        # ✅ TRIGGER EMAIL
        if state.fatigue_score >= cfg.fatigue_threshold:
            email_alert.send(state)

        time.sleep(10)