"""
Visual alert system — cockpit HUD with full metrics display.

MY IDEAS:
- Gaze direction indicator (mini eyeball diagram)
- PERCLOS bar (separate from fatigue — pilots understand this metric)
- Session timer with color warning after 45min / 90min
- Trend arrow — shows if fatigue is rising or stabilizing
- Microsleep EMERGENCY overlay — full screen flash with countdown
- Adaptive HUD brightness — dims when no alert, brightens on warning
- Head pose 3D indicator (cross/crosshair showing nod/tilt direction)
"""

import cv2
import numpy as np
import time
import math
from typing import Tuple

# BGR colors
C_GREEN   = (30,  210,  50)
C_AMBER   = (0,   200, 255)
C_ORANGE  = (0,   140, 255)
C_RED     = (0,    30, 220)
C_WHITE   = (255, 255, 255)
C_BLACK   = (0,     0,   0)
C_DARK    = (12,   16,  24)
C_CYAN    = (255, 220,   0)
C_TEAL    = (200, 220,  80)

LEVEL_C = {"NORMAL": C_GREEN, "CAUTION": C_AMBER, "WARNING": C_ORANGE, "CRITICAL": C_RED}
FONT  = cv2.FONT_HERSHEY_DUPLEX
FONTM = cv2.FONT_HERSHEY_PLAIN


class FlashAlert:
    def __init__(self, cfg):
        self.cfg = cfg
        self._active = False
        self._frame = 0
        self._total = cfg.flash_duration_frames
        self._microsleep_active = False

    def trigger(self, microsleep=False):
        self._active = True
        self._frame = 0
        self._microsleep_active = microsleep

    def apply(self, frame, level):
        if not self._active or not self.cfg.flash_enabled:
            return frame
        self._frame += 1
        prog = self._frame / self._total
        if prog >= 1.0:
            self._active = False
            self._microsleep_active = False
            return frame

        # Microsleep = solid red pulse
        if self._microsleep_active:
            alpha = 0.6 * abs(math.sin(self._frame * 0.3))
            ov = np.zeros_like(frame); ov[:] = (0, 0, 180)
            cv2.addWeighted(ov, alpha, frame, 1-alpha, 0, frame)
            # Big MICROSLEEP text
            h, w = frame.shape[:2]
            if int(time.time()*3) % 2 == 0:
                cv2.putText(frame, "! MICROSLEEP DETECTED !",
                    (w//2 - 220, h//2), FONT, 1.4, C_WHITE, 3, cv2.LINE_AA)
        else:
            phase = (self._frame // 5) % 2
            ov_color = (0, 0, 160) if phase == 0 else (200, 200, 200)
            alpha = max(0, 0.50*(1-prog)*math.sin(prog*math.pi*4))
            ov = np.full_like(frame, ov_color)
            cv2.addWeighted(ov, alpha, frame, 1-alpha, 0, frame)

        # Animated border
        h, w = frame.shape[:2]
        bw = max(4, int(14*(1-prog)))
        cv2.rectangle(frame, (0,0), (w-1,h-1), LEVEL_C.get(level,C_RED), bw)
        return frame

    @property
    def is_active(self): return self._active


class HUDOverlay:
    PANEL_W = 280

    def __init__(self, cfg):
        self.cfg = cfg
        self._start = time.time()

    def draw(self, frame, state, fps, monitoring=True):
        if not monitoring:
            self._draw_standby(frame)
            return frame

        h, w = frame.shape[:2]
        self._draw_panel(frame, state, h)
        self._draw_top_bar(frame, state, w, h)
        self._draw_bottom_bar(frame, state, fps, w, h)
        self._draw_fatigue_gauge(frame, state)
        self._draw_perclos_bar(frame, state)
        self._draw_head_pose_indicator(frame, state, w, h)
        self._draw_gaze_indicator(frame, state, w, h)
        self._draw_session_timer(frame, state, w, h)

        if state.alert_level in ("WARNING", "CRITICAL") or state.microsleep:
            self._draw_alert_banner(frame, state, w, h)

        return frame

    def _draw_standby(self, frame):
        h, w = frame.shape[:2]
        overlay = frame.copy()
        cv2.rectangle(overlay, (0,0),(w,h), C_DARK, -1)
        cv2.addWeighted(overlay, 0.75, frame, 0.25, 0, frame)
        cv2.putText(frame, "PFDS v3 — STANDBY", (w//2-180, h//2-20),
                    FONT, 1.0, C_TEAL, 2, cv2.LINE_AA)
        cv2.putText(frame, "Press  SPACE  to begin monitoring",
                    (w//2-200, h//2+20), FONTM, 1.4, (150,150,150), 1, cv2.LINE_AA)

    def _panel_bg(self, frame, y1, y2, x1=0, alpha=0.80):
        x2 = self.PANEL_W
        roi = frame[y1:y2, x1:x2].copy()
        bg = np.zeros_like(roi); bg[:] = C_DARK
        cv2.addWeighted(bg, alpha, roi, 1-alpha, 0, roi)
        frame[y1:y2, x1:x2] = roi

    def _draw_panel(self, frame, state, h):
        pw = self.PANEL_W
        self._panel_bg(frame, 0, h)
        color = LEVEL_C.get(state.alert_level, C_GREEN)
        cv2.line(frame, (pw,0),(pw,h), color, 2)

        # Header
        cv2.putText(frame, "PFDS v3.0", (10,26), FONT, 0.55, C_WHITE, 1, cv2.LINE_AA)
        cv2.putText(frame, "PILOT MONITOR", (10,46), FONTM, 1.1, color, 1, cv2.LINE_AA)
        cv2.line(frame, (10,52),(pw-10,52), color, 1)

        # Metrics
        y, dy = 76, 36
        rows = [
            ("EAR",        f"{state.ear:.3f}",
             self._ear_color(state.ear)),
            ("PERCLOS",    f"{state.perclos:.1%}",
             C_RED if state.perclos > self.cfg.perclos_threshold else
             C_AMBER if state.perclos > 0.08 else C_GREEN),
            ("BLINK/min",  f"{state.blink_rate*60:.1f}",
             C_AMBER if state.blink_rate > 0.4 or state.blink_rate < 0.05 else C_GREEN),
            ("BLINKS",     f"{state.total_blinks}", C_WHITE),
            ("PITCH",      f"{state.pitch:.1f}°",
             C_ORANGE if abs(state.pitch)>self.cfg.head_pitch_threshold else C_GREEN),
            ("YAW",        f"{state.yaw:.1f}°",
             C_ORANGE if abs(state.yaw)>self.cfg.distraction_yaw_threshold else C_GREEN),
            ("ROLL",       f"{state.roll:.1f}°",
             C_ORANGE if abs(state.roll)>self.cfg.head_roll_threshold else C_GREEN),
            ("YAWNS",      f"{state.yawn_count}",
             C_AMBER if state.yawn_count > 0 else C_GREEN),
        ]
        for label, val, col in rows:
            cv2.putText(frame, label, (12, y), FONTM, 0.9, (140,140,155), 1, cv2.LINE_AA)
            cv2.putText(frame, val,   (12, y+16), FONT, 0.52, col, 1, cv2.LINE_AA)
            cv2.line(frame, (12,y+22),(pw-12,y+22),(35,38,50),1)
            y += dy

        # Status dots
        y += 8
        self._dot(frame, "FACE",       state.face_visible,  12, y)
        self._dot(frame, "DISTRACT",  state.distracted,    90, y, inv=True)
        self._dot(frame, "YAWN",      state.is_yawning,   180, y, inv=True)

        # Microsleep warning
        if state.microsleep:
            y += 24
            pulse = int(time.time()*4)%2
            col = C_RED if pulse else C_WHITE
            cv2.putText(frame, f"MICROSLEEP! {state.eye_closed_frames}f",
                        (10, y), FONT, 0.52, col, 1, cv2.LINE_AA)

        # Trend arrow
        y += 30
        trend = state.score_trend
        if trend > 0.005:
            sym, col = "RISING  ▲", C_RED
        elif trend < -0.005:
            sym, col = "FALLING ▼", C_GREEN
        else:
            sym, col = "STABLE  ─", C_AMBER
        cv2.putText(frame, f"TREND: {sym}", (12, y), FONTM, 0.9, col, 1, cv2.LINE_AA)

    def _dot(self, frame, label, active, x, y, inv=False):
        col = (C_RED if active else C_GREEN) if inv else (C_GREEN if active else (60,60,70))
        cv2.circle(frame, (x+5, y-4), 5, col, -1)
        cv2.putText(frame, label, (x+14,y), FONTM, 0.75, (170,170,170), 1, cv2.LINE_AA)

    def _draw_top_bar(self, frame, state, w, h):
        pw = self.PANEL_W
        roi = frame[0:38, pw:w].copy()
        bg = np.zeros_like(roi); bg[:] = C_DARK
        cv2.addWeighted(bg, 0.78, roi, 0.22, 0, roi)
        frame[0:38, pw:w] = roi

        color = LEVEL_C.get(state.alert_level, C_GREEN)
        cv2.putText(frame, f"STATUS: {state.alert_level}",
                    (pw+12, 26), FONT, 0.80, color, 1, cv2.LINE_AA)

        if state.alert_level == "CRITICAL" and int(time.time()*2)%2==0:
            cv2.putText(frame, "⚠  FATIGUE ALERT — TAKE ACTION NOW",
                        (pw+220, 26), FONTM, 1.1, C_RED, 1, cv2.LINE_AA)

    def _draw_bottom_bar(self, frame, state, fps, w, h):
        pw = self.PANEL_W
        roi = frame[h-28:h, pw:w].copy()
        bg = np.zeros_like(roi); bg[:] = C_DARK
        cv2.addWeighted(bg, 0.78, roi, 0.22, 0, roi)
        frame[h-28:h, pw:w] = roi

        ts = time.strftime("%H:%M:%S")
        cv2.putText(frame, f"UTC {ts}", (pw+10, h-10),
                    FONTM, 1.0, (120,120,130), 1, cv2.LINE_AA)
        cv2.putText(frame, f"{fps:.0f} FPS", (w-80, h-10),
                    FONTM, 1.0, (100,100,110), 1, cv2.LINE_AA)
        cv2.putText(frame, "SPACE=Start/Stop  Q=Quit  S=Screenshot  R=Reset",
                    (pw+120, h-10), FONTM, 0.85, (70,70,80), 1, cv2.LINE_AA)

    def _draw_fatigue_gauge(self, frame, state):
        """Fatigue score bar at bottom of left panel."""
        bx, by = 12, frame.shape[0]-70
        bw, bh = self.PANEL_W-24, 12
        score = state.fatigue_score
        thresh = self.cfg.fatigue_threshold

        cv2.rectangle(frame, (bx,by),(bx+bw,by+bh),(35,38,50),-1)
        filled = int(bw*score)
        if filled > 0:
            color = LEVEL_C.get(state.alert_level, C_GREEN)
            cv2.rectangle(frame, (bx,by),(bx+filled,by+bh), color,-1)

        # Threshold line
        tx = bx + int(bw*thresh)
        cv2.line(frame,(tx,by-3),(tx,by+bh+3),C_WHITE,2)

        cv2.putText(frame, "FATIGUE", (bx, by-5),
                    FONTM, 0.85, (140,140,155), 1, cv2.LINE_AA)
        cv2.putText(frame, f"{score:.0%}", (bx+bw-36,by+10),
                    FONTM, 0.9, C_WHITE, 1, cv2.LINE_AA)

    def _draw_perclos_bar(self, frame, state):
        """PERCLOS gauge — separate bar, pilots know this metric."""
        bx, by = 12, frame.shape[0]-46
        bw, bh = self.PANEL_W-24, 8
        p = state.perclos
        thresh = self.cfg.perclos_threshold

        cv2.rectangle(frame,(bx,by),(bx+bw,by+bh),(35,38,50),-1)
        filled = int(bw * min(1.0, p/max(thresh*1.5,0.001)))
        if filled > 0:
            col = C_RED if p>thresh else C_AMBER if p>0.08 else C_GREEN
            cv2.rectangle(frame,(bx,by),(bx+filled,by+bh),col,-1)
        tx = bx + int(bw * thresh/max(thresh*1.5,0.001))
        cv2.line(frame,(tx,by-2),(tx,by+bh+2),(220,220,220),1)
        cv2.putText(frame, f"PERCLOS {p:.1%}", (bx,by-3),
                    FONTM, 0.8, (130,130,145), 1, cv2.LINE_AA)

    def _draw_head_pose_indicator(self, frame, state, w, h):
        """Mini crosshair showing head pitch/roll — intuitive at a glance."""
        cx = w - 70; cy = 90; r = 45
        overlay = frame.copy()
        cv2.circle(overlay, (cx,cy), r, C_DARK, -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        cv2.circle(frame, (cx,cy), r, (50,55,70), 1)

        # Crosshair lines
        cv2.line(frame,(cx-r,cy),(cx+r,cy),(40,44,55),1)
        cv2.line(frame,(cx,cy-r),(cx,cy+r),(40,44,55),1)

        # Head position dot
        px = int(cx + np.clip(state.yaw/45.0, -1,1)*r*0.8)
        py = int(cy - np.clip(state.pitch/30.0,-1,1)*r*0.8)
        color = LEVEL_C.get(state.alert_level, C_GREEN)
        cv2.circle(frame,(px,py),6,color,-1)
        cv2.circle(frame,(px,py),6,C_WHITE,1)

        # Roll indicator (arc at edge)
        roll_rad = math.radians(np.clip(state.roll,-45,45))
        ex = int(cx + math.sin(roll_rad)*r)
        ey = int(cy - math.cos(roll_rad)*r)
        cv2.line(frame,(cx,cy),(ex,ey),(200,160,80),2)

        cv2.putText(frame,"HEAD",(cx-18,cy+r+14),FONTM,0.85,(100,100,110),1,cv2.LINE_AA)

    def _draw_gaze_indicator(self, frame, state, w, h):
        """Mini eye diagram showing gaze direction."""
        cx = w-70; cy = 190; ew = 38; eh = 20
        overlay = frame.copy()
        cv2.ellipse(overlay,(cx,cy),(ew,eh),0,0,360,C_DARK,-1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        cv2.ellipse(frame,(cx,cy),(ew,eh),0,0,360,(50,55,70),1)

        if state.iris_detected if hasattr(state,'iris_detected') else True:
            ix = int(cx + state.gaze_x * ew * 0.5)
            iy = int(cy + state.gaze_y * eh * 0.5)
            cv2.circle(frame,(ix,iy),8,(200,160,50),-1)
            cv2.circle(frame,(ix,iy),4,(255,220,80),-1)
            cv2.circle(frame,(ix,iy),8,(150,120,40),1)

        cv2.putText(frame,"GAZE",(cx-18,cy+eh+14),FONTM,0.85,(100,100,110),1,cv2.LINE_AA)

    def _draw_session_timer(self, frame, state, w, h):
        """Session duration with color warning for fatigue windows."""
        mins = state.session_minutes
        h_m, m_m = int(mins)//60, int(mins)%60
        ts = f"{h_m:02d}:{m_m:02d}"
        if mins < 45:   col = C_GREEN
        elif mins < 90: col = C_AMBER
        else:           col = C_RED   # FAA recommended rest after 90 min

        cv2.putText(frame, f"SESSION {ts}", (w-135, h-40),
                    FONTM, 1.0, col, 1, cv2.LINE_AA)
        if mins >= 90:
            if int(time.time()*2)%2==0:
                cv2.putText(frame, "REST RECOMMENDED", (w-160, h-24),
                            FONTM, 0.9, C_RED, 1, cv2.LINE_AA)

    def _draw_alert_banner(self, frame, state, w, h):
        pw = self.PANEL_W
        cx = (w+pw)//2; cy = h//2
        color = LEVEL_C.get(state.alert_level, C_RED)
        alpha = 0.55 + 0.45*abs(math.sin(time.time()*3.5))

        if state.microsleep:
            text = "!! MICROSLEEP — WAKE UP !!"
        elif state.alert_level == "CRITICAL":
            text = "⚠  CRITICAL FATIGUE  ⚠"
        else:
            text = "FATIGUE WARNING"

        sz = cv2.getTextSize(text, FONT, 1.1, 2)[0]
        x = cx - sz[0]//2
        pad = 14
        ov = frame.copy()
        cv2.rectangle(ov,(x-pad,cy-sz[1]-pad),(x+sz[0]+pad,cy+pad),(0,0,0),-1)
        cv2.addWeighted(ov, 0.65, frame, 0.35, 0, frame)
        cv2.putText(frame, text, (x,cy), FONT, 1.1, color, 2, cv2.LINE_AA)

    def _ear_color(self, ear):
        if ear < self.cfg.ear_threshold: return C_RED
        if ear < self.cfg.ear_threshold+0.04: return C_ORANGE
        if ear < self.cfg.ear_threshold+0.08: return C_AMBER
        return C_GREEN
