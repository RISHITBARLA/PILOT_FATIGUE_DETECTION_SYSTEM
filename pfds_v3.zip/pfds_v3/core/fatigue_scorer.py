"""
Fatigue Scorer — optimized for fast, accurate response.
Key improvements:
- Instant microsleep/sudden drop override (no rolling average delay)
- EAR score reacts in 2 frames instead of waiting for window
- Score rises fast, recovers slowly (asymmetric — safer)
- Component scores cached, only full recalc every N frames
"""
import time, collections, math
from dataclasses import dataclass, field
from typing import Deque, List


@dataclass
class BlinkStats:
    total: int = 0
    timestamps: Deque = field(default_factory=lambda: collections.deque(maxlen=300))
    closed_frames: int = 0
    is_blinking: bool = False

    def add(self, t):
        self.total += 1
        self.timestamps.append(t)

    def rate(self, window=30.0):
        now = time.time()
        return sum(1 for ts in self.timestamps if ts > now - window) / window


@dataclass
class FatigueState:
    fatigue_score: float = 0.0
    ear: float = 0.30
    mar: float = 0.0
    pitch: float = 0.0
    yaw: float = 0.0
    roll: float = 0.0
    perclos: float = 0.0
    gaze_x: float = 0.0
    gaze_y: float = 0.0
    blink_rate: float = 0.2
    total_blinks: int = 0
    yawn_count: int = 0
    is_yawning: bool = False
    face_visible: bool = True
    distracted: bool = False
    microsleep: bool = False
    eye_closed_frames: int = 0
    alert_level: str = "NORMAL"
    component_scores: dict = field(default_factory=dict)
    score_trend: float = 0.0
    session_minutes: float = 0.0
    baseline_ear: float = 0.30
    calibrated: bool = False
    debug_info: str = ""
    fatigue_types: List[str] = field(default_factory=list)
    primary_cause: str = "Normal"
    neck_bend_detected: bool = False
    head_velocity: float = 0.0
    sudden_drop: bool = False


class FatigueScorer:
    LEVELS = [(0.75, "CRITICAL"), (0.55, "WARNING"), (0.38, "CAUTION"), (0.0, "NORMAL")]

    def __init__(self, config):
        self.cfg = config
        self.blink = BlinkStats()
        self.state = FatigueState()
        fps = config.target_fps

        # Score history — short window for fast response
        self._score_hist: Deque = collections.deque(
            maxlen=fps * config.score_window_seconds)
        self._trend_hist: Deque = collections.deque(maxlen=fps * 6)

        self._mouth_open = 0
        self._yawn_count = 0
        self._ear_buf: Deque = collections.deque(maxlen=6)  # less smoothing = faster

        # Adaptive baseline
        self._baseline_buf: Deque = collections.deque(
            maxlen=fps * config.calibration_seconds)
        self._baseline_locked = False
        self._baseline_ear = 0.30
        self._dynamic_threshold = config.ear_threshold

        # PERCLOS
        self._eye_state_buf: Deque = collections.deque(
            maxlen=fps * config.perclos_window_seconds)
        self._consecutive_closed = 0
        self._awake_streak = 0

        # Head velocity / neck bend
        self._pitch_hist: Deque = collections.deque(maxlen=10)
        self._roll_hist:  Deque = collections.deque(maxlen=10)
        self._neck_bend_frames = 0
        self._sudden_drop_frames = 0
        self._baseline_pitch = 0.0
        self._baseline_pitch_buf: Deque = collections.deque(maxlen=fps * 15)

        self._session_fatigue = 0.0
        self._start_time = time.time()

        # Fast path: track instant EAR score separately
        self._instant_ear_score = 0.0

    def update(self, metrics) -> FatigueState:
        now = time.time()
        self.state.session_minutes = (now - self._start_time) / 60.0

        if not metrics.face_detected:
            self.state.face_visible = False
            self._consecutive_closed += 1
            self._score_hist.append(min(0.5, self.state.fatigue_score + 0.02))
            self.state.fatigue_score = sum(self._score_hist) / len(self._score_hist)
            self.state.alert_level = self._level(self.state.fatigue_score)
            self.state.microsleep = self._consecutive_closed >= self.cfg.microsleep_frames
            self.state.calibrated = self._baseline_locked
            self.state.primary_cause = "Face Not Visible"
            self.state.fatigue_types = ["Face Not Visible"]
            return self.state

        self.state.face_visible = True

        # ── EAR smoothing (shorter buffer = faster) ────────────────────
        self._ear_buf.append(metrics.ear)
        ear = sum(self._ear_buf) / len(self._ear_buf)

        # ── Baseline calibration ───────────────────────────────────────
        if ear > 0.24:
            self._baseline_buf.append(ear)
        if abs(metrics.pitch) < 20:
            self._baseline_pitch_buf.append(metrics.pitch)

        if not self._baseline_locked and \
                len(self._baseline_buf) >= 15 * self.cfg.target_fps:
            sorted_buf = sorted(self._baseline_buf)
            p10 = len(sorted_buf) // 10
            p90 = len(sorted_buf) * 9 // 10
            trimmed = sorted_buf[p10:p90]
            self._baseline_ear = sum(trimmed) / max(len(trimmed), 1)
            self._dynamic_threshold = self._baseline_ear * self.cfg.ear_threshold_ratio
            if self._baseline_pitch_buf:
                self._baseline_pitch = sum(self._baseline_pitch_buf) / len(self._baseline_pitch_buf)
            self._baseline_locked = True
            print(f"\n[Scorer] ✓ Calibration complete!")
            print(f"[Scorer]   Baseline EAR : {self._baseline_ear:.3f}")
            print(f"[Scorer]   EAR threshold: {self._dynamic_threshold:.3f}")
            print(f"[Scorer]   Base pitch   : {self._baseline_pitch:.1f}°\n")

        thresh = self._dynamic_threshold if self._baseline_locked else self.cfg.ear_threshold

        # ── Update state ───────────────────────────────────────────────
        self.state.ear = ear
        self.state.mar = metrics.mar
        self.state.pitch = metrics.pitch
        self.state.yaw = metrics.yaw
        self.state.roll = metrics.roll
        self.state.perclos = metrics.perclos
        self.state.gaze_x = metrics.gaze_x
        self.state.gaze_y = metrics.gaze_y
        self.state.eye_closed_frames = metrics.eye_closed_frames
        self.state.microsleep = metrics.microsleep
        self.state.distracted = abs(metrics.yaw) > self.cfg.distraction_yaw_threshold
        self.state.calibrated = self._baseline_locked
        self.state.baseline_ear = self._baseline_ear

        # ── PERCLOS ────────────────────────────────────────────────────
        closed = ear < thresh
        self._eye_state_buf.append(1 if closed else 0)
        if closed:
            self._consecutive_closed += 1
            self._awake_streak = 0
        else:
            self._consecutive_closed = 0
            if ear > self._baseline_ear * 0.80:
                self._awake_streak += 1
        perclos = sum(self._eye_state_buf) / max(len(self._eye_state_buf), 1)
        self.state.perclos = perclos

        # ── Blink ──────────────────────────────────────────────────────
        self._update_blink(ear, now, thresh)

        # ── Yawn ───────────────────────────────────────────────────────
        self._update_yawn(metrics.mar)

        # ── Neck bend ──────────────────────────────────────────────────
        neck_score, sudden = self._update_neck(metrics.pitch, metrics.roll)
        self.state.neck_bend_detected = self._neck_bend_frames > 3
        self.state.sudden_drop = sudden
        self.state.head_velocity = self._head_vel()

        # ── Session fatigue ────────────────────────────────────────────
        session_h = self.state.session_minutes / 60.0
        self._session_fatigue = min(0.12, session_h * 0.05)

        # ── Component scores ───────────────────────────────────────────
        ear_score     = self._s_ear(ear, thresh)
        perclos_score = self._s_perclos(perclos)
        blink_score   = self._s_blink()
        head_score    = self._s_head(metrics.pitch, metrics.yaw, metrics.roll)
        yawn_score    = self._s_yawn()
        eye_score     = ear_score * 0.35 + perclos_score * 0.65

        raw = (
            self.cfg.weight_ear   * eye_score +
            self.cfg.weight_blink * blink_score +
            self.cfg.weight_head  * head_score +
            self.cfg.weight_yawn  * yawn_score
        )

        # ── INSTANT overrides — no rolling average delay ───────────────
        if metrics.microsleep:
            raw = max(raw, 0.88)   # instant CRITICAL
        if sudden:
            raw = max(raw, 0.78)   # instant WARNING/CRITICAL
        elif self.state.neck_bend_detected:
            raw = max(raw, neck_score * 0.8)
        if self.state.distracted:
            raw = min(1.0, raw + 0.18)

        raw = min(1.0, raw + self._session_fatigue)

        # ── Asymmetric response: rises fast, falls slow ────────────────
        # This makes alerts feel instant while avoiding rapid flickering
        prev = self.state.fatigue_score
        if raw > prev:
            # Rising: weight new score heavily (fast rise)
            blended = prev * 0.3 + raw * 0.7
        else:
            # Falling: weight history heavily (slow recovery)
            blended = prev * 0.7 + raw * 0.3

        # Cap during calibration
        if not self._baseline_locked:
            blended = min(blended, 0.32)

        # Still keep short rolling avg for stability
        self._score_hist.append(blended)
        score = sum(self._score_hist) / len(self._score_hist)

        # ── Trend ──────────────────────────────────────────────────────
        self._trend_hist.append(score)
        if len(self._trend_hist) >= 4:
            half = len(self._trend_hist) // 2
            h1 = list(self._trend_hist)[:half]
            h2 = list(self._trend_hist)[half:]
            self.state.score_trend = round(
                sum(h2)/len(h2) - sum(h1)/len(h1), 4)

        self.state.fatigue_score = round(score, 3)
        self.state.alert_level   = self._level(score)
        self.state.blink_rate    = round(self.blink.rate(), 3)
        self.state.total_blinks  = self.blink.total
        self.state.yawn_count    = self._yawn_count

        # ── Classify fatigue type ──────────────────────────────────────
        types, primary = self._classify(
            ear, thresh, perclos, metrics.pitch,
            metrics.yaw, metrics.roll, metrics.mar,
            sudden, metrics.microsleep)
        self.state.fatigue_types  = types
        self.state.primary_cause  = primary

        self.state.component_scores = {
            "ear":     round(ear_score,     3),
            "perclos": round(perclos_score, 3),
            "blink":   round(blink_score,   3),
            "head":    round(head_score,    3),
            "yawn":    round(yawn_score,    3),
            "neck":    round(neck_score,    3),
        }
        return self.state

    # ── Neck bend ────────────────────────────────────────────────────────────

    def _update_neck(self, pitch, roll):
        self._pitch_hist.append(pitch)
        self._roll_hist.append(roll)
        sudden = False
        neck_score = 0.0

        if len(self._pitch_hist) >= 6:
            recent = list(self._pitch_hist)
            r_avg = sum(recent[-3:]) / 3
            o_avg = sum(recent[:3])  / 3
            delta = r_avg - o_avg
            if delta > self.cfg.sudden_drop_threshold:
                self._sudden_drop_frames = 25
                sudden = True

        if self._sudden_drop_frames > 0:
            self._sudden_drop_frames -= 1
            sudden = self._sudden_drop_frames > 0

        pitch_offset = pitch - self._baseline_pitch
        is_bent = (pitch_offset > self.cfg.neck_bend_pitch_threshold or
                   abs(roll) > self.cfg.neck_bend_roll_threshold)

        if is_bent:
            self._neck_bend_frames = min(self._neck_bend_frames + 1, 90)
        else:
            self._neck_bend_frames = max(0, self._neck_bend_frames - 3)

        neck_score = min(1.0, self._neck_bend_frames / (self.cfg.target_fps * 2.5))
        return neck_score, sudden

    def _head_vel(self):
        if len(self._pitch_hist) < 3:
            return 0.0
        r = list(self._pitch_hist)[-5:]
        d = [abs(r[i]-r[i-1]) for i in range(1,len(r))]
        return sum(d)/len(d) if d else 0.0

    # ── Scorers ───────────────────────────────────────────────────────────────

    def _s_ear(self, ear, thresh):
        baseline = self._baseline_ear
        if ear <= thresh * 0.5:    return 1.0
        if ear >= baseline * 0.85: return 0.0
        return max(0.0, 1.0-(ear-thresh)/max(baseline*0.85-thresh, 0.01))

    def _s_perclos(self, p):
        t = self.cfg.perclos_threshold
        if p <= t * 0.4: return 0.0
        return min(1.0, (p - t*0.4) / (t*0.6))

    def _s_blink(self):
        rate = self.blink.rate(20.0)
        if 0.08 <= rate <= 0.45: return 0.0
        if rate < 0.08: return min(1.0, (0.08-rate)/0.08)
        return min(1.0, (rate-0.45)/0.45*0.5)

    def _s_head(self, pitch, yaw, roll):
        pt = self.cfg.head_pitch_threshold
        rt = self.cfg.head_roll_threshold
        yt = self.cfg.distraction_yaw_threshold
        ps = max(0.0,(abs(pitch)-pt)/(pt*1.2))
        rs = max(0.0,(abs(roll)-rt)/(rt*1.2))
        ys = max(0.0,(abs(yaw)-yt)/yt)*0.4
        return min(1.0, max(ps, rs*0.7, ys))

    def _s_yawn(self):
        if self._yawn_count == 0: return 0.0
        return min(1.0, self._yawn_count/3.0)*0.85

    # ── Updaters ──────────────────────────────────────────────────────────────

    def _update_blink(self, ear, now, thresh):
        if ear < thresh:
            self.blink.closed_frames += 1
            self.blink.is_blinking = True
        else:
            if self.blink.is_blinking and 1 <= self.blink.closed_frames <= 12:
                self.blink.add(now)
            self.blink.closed_frames = 0
            self.blink.is_blinking = False

    def _update_yawn(self, mar):
        if mar > self.cfg.mar_threshold:
            self._mouth_open += 1
        else:
            if self._mouth_open >= self.cfg.yawn_consec_frames:
                self._yawn_count += 1
            self._mouth_open = 0
        self.state.is_yawning = self._mouth_open >= self.cfg.yawn_consec_frames

    def _classify(self, ear, thresh, perclos, pitch, yaw, roll, mar, sudden, micro):
        types = []
        if micro:           types.append("Microsleep")
        if sudden:          types.append("Sudden Head Drop")
        if self._neck_bend_frames > 5:
            pitch_off = pitch - self._baseline_pitch
            if pitch_off > self.cfg.neck_bend_pitch_threshold:
                types.append("Head Drooping Forward")
            if abs(roll) > self.cfg.neck_bend_roll_threshold:
                types.append("Head Lolling Sideways")
        if ear < thresh * 0.75:    types.append("Eyes Closing")
        elif perclos > self.cfg.perclos_threshold: types.append("High Eye Closure")
        if self.state.is_yawning:  types.append("Yawning")
        if self._yawn_count >= 2:  types.append(f"Repeated Yawning {self._yawn_count}x")
        if abs(pitch) > self.cfg.head_pitch_threshold * 1.4 and \
                "Head Drooping Forward" not in types:
            types.append("Head Nodding")
        if abs(yaw) > self.cfg.distraction_yaw_threshold:
            types.append("Looking Away")
        if self.blink.rate() < 0.05: types.append("Reduced Blinking")
        if not types: return ["Normal"], "Normal"
        priority = ["Microsleep","Sudden Head Drop","Eyes Closing",
                    "Head Drooping Forward","Head Lolling Sideways",
                    "Head Nodding","High Eye Closure","Yawning",
                    "Repeated Yawning","Looking Away","Reduced Blinking"]
        primary = types[0]
        for p in priority:
            match = next((t for t in types if p in t), None)
            if match:
                primary = match
                break
        return types, primary

    def _level(self, s):
        for t, l in self.LEVELS:
            if s >= t: return l
        return "NORMAL"

    def reset(self):
        self.__init__(self.cfg)
        print("[Scorer] Reset complete.")
