"""Threaded camera capture — decouples I/O from processing."""
import cv2, threading, time, queue
from typing import Optional, Tuple
import numpy as np

class ThreadedCapture:
    def __init__(self, idx, w=1280, h=720, fps=30):
        self.idx, self.w, self.h, self.fps = idx, w, h, fps
        self._cap = None
        self._q: queue.Queue = queue.Queue(maxsize=2)
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._latest: Optional[np.ndarray] = None
        self._lock = threading.Lock()

    def start(self) -> bool:
        self._cap = cv2.VideoCapture(self.idx)
        if not self._cap.isOpened():
            print(f"[Camera] Cannot open camera {self.idx}")
            return False
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH,  self.w)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.h)
        self._cap.set(cv2.CAP_PROP_FPS,          self.fps)
        self._cap.set(cv2.CAP_PROP_BUFFERSIZE,   1)
        aw = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        ah = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"[Camera] Opened {self.idx}: {aw}x{ah}")
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return True

    def _loop(self):
        while self._running:
            ret, frame = self._cap.read()
            if not ret: time.sleep(0.01); continue
            with self._lock: self._latest = frame
            try: self._q.put_nowait(frame)
            except queue.Full:
                try: self._q.get_nowait(); self._q.put_nowait(frame)
                except queue.Empty: pass

    def read(self) -> Tuple[bool, Optional[np.ndarray]]:
        try: return True, self._q.get(timeout=0.05)
        except queue.Empty:
            with self._lock:
                if self._latest is not None: return True, self._latest.copy()
            return False, None

    def stop(self):
        self._running = False
        if self._thread: self._thread.join(timeout=2)
        if self._cap: self._cap.release()
