"""
Main application — orchestrates all subsystems.

MY IDEAS:
- START/STOP toggle with SPACE bar (monitoring state machine)
- Calibration phase: first 30s learns your personal EAR baseline
- Pre-flight check screen (camera OK, face detected, lighting check)
- Idle standby mode: minimal CPU when not monitoring
- Graceful degradation: if MediaPipe slow, auto-increase frame skip
- FPS adaptive: dynamically adjusts skip_frames to maintain target FPS
"""

import cv2, time, sys, os, threading
import numpy as np

from core.video_capture  import ThreadedCapture
from core.detector       import FatigueDetector
from core.fatigue_scorer import FatigueScorer
from alerts.audio_alert  import AudioAlert
from alerts.email_alert  import ATCEmailAlert
from alerts.visual_alert import FlashAlert, HUDOverlay
from utils.logger        import FatigueLogger
from utils.screenshot    import ScreenshotManager


class AppState:
    STANDBY    = "STANDBY"      # waiting for pilot to press START
    CALIBRATE  = "CALIBRATE"    # learning baseline (first 30s)
    MONITORING = "MONITORING"   # active detection
    PAUSED     = "PAUSED"       # paused (landed / break)


class FatigueDetectionApp:
    WIN = "✈  Pilot Fatigue Detection System v3"

    def __init__(self, cfg):
        self.cfg = cfg
        print("[App] Initialising…")

        self.capture    = ThreadedCapture(cfg.camera_index, cfg.frame_width, cfg.frame_height, cfg.target_fps)
        self.detector   = FatigueDetector(cfg)
        self.scorer     = FatigueScorer(cfg)
        self.flash      = FlashAlert(cfg)
        self.hud        = HUDOverlay(cfg)
        self.audio      = AudioAlert(cfg)
        self.email      = ATCEmailAlert(cfg)
        self.logger     = FatigueLogger(cfg)
        self.screenshot = ScreenshotManager(cfg)

        self._state      = AppState.STANDBY
        self._running    = False
        self._frame_idx  = 0
        self._skip       = cfg.skip_frames
        self._fps        = 0.0
        self._fps_cnt    = 0
        self._fps_t      = time.time()
        self._alert_t    = 0.0
        self._alert_n    = 0
        self._calib_done = False
        self._calib_t    = 0.0
        self._cached_state  = None
        self._cached_lm     = None

        print("[App] Ready. Press SPACE to start monitoring.")

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self):
        if not self.capture.start():
            print("[App] FATAL: Cannot open camera.")
            sys.exit(1)
        time.sleep(0.4)

        cv2.namedWindow(self.WIN, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WIN, 1280, 720)
        self._running = True
        self.logger.session_start()
        target_dt = 1.0 / self.cfg.target_fps

        try:
            while self._running:
                t0 = time.time()

                ret, frame = self.capture.read()
                if not ret or frame is None:
                    time.sleep(0.01); continue

                self._frame_idx += 1
                display = self._process(frame)
                cv2.imshow(self.WIN, display)
                self._fps_cnt += 1

                now = time.time()
                if now - self._fps_t >= 1.0:
                    self._fps = self._fps_cnt / (now - self._fps_t)
                    self._fps_cnt = 0
                    self._fps_t = now
                    # Adaptive frame skip to maintain FPS
                    if self._fps < self.cfg.target_fps * 0.7 and self._skip < 4:
                        self._skip += 1
                    elif self._fps > self.cfg.target_fps * 0.95 and self._skip > 1:
                        self._skip -= 1

                key = cv2.waitKey(1) & 0xFF
                self._handle_key(key, display)

                if cv2.getWindowProperty(self.WIN, cv2.WND_PROP_VISIBLE) < 1:
                    break

                elapsed = time.time() - t0
                if (dt := target_dt - elapsed) > 0:
                    time.sleep(dt)

        except KeyboardInterrupt:
            print("\n[App] Interrupted.")
        finally:
            self._shutdown()

    # ── Frame processing ──────────────────────────────────────────────────────

    def _process(self, frame):
        monitoring = self._state in (AppState.MONITORING, AppState.CALIBRATE)

        if not monitoring:
            # Standby: just show feed + overlay
            display = frame.copy()
            self.hud.draw(display, self._empty_state(), self._fps, monitoring=False)
            self._draw_state_banner(display)
            return display

        # ── Active detection ─────────────────────────────────────────────
        if self._frame_idx % self._skip == 0:
            metrics, annotated = self.detector.process_frame(frame)
            state = self.scorer.update(metrics)
            self._cached_state = state
            self._cached_lm    = metrics.landmarks_2d
        else:
            annotated = frame.copy()
            state = self._cached_state or self.scorer.state
            # Re-draw landmarks on new frame
            if self._cached_lm is not None:
                self.detector._draw_contours(annotated, self._cached_lm.astype(np.int32))

        # ── Calibration phase ────────────────────────────────────────────
        if self._state == AppState.CALIBRATE:
            elapsed = time.time() - self._calib_t
            remaining = max(0, 30 - elapsed)
            self._draw_calibration_banner(annotated, remaining, state)
            if elapsed >= 30:
                self._state = AppState.MONITORING
                print("[App] Calibration complete. Monitoring active.")

        # ── Alerts ───────────────────────────────────────────────────────
        if self._state == AppState.MONITORING:
            self._handle_alerts(state, annotated)

        # ── HUD ──────────────────────────────────────────────────────────
        display = self.hud.draw(annotated, state, self._fps, monitoring=True)
        display = self.flash.apply(display, state.alert_level)
        self._draw_state_banner(display)
        return display

    def _handle_alerts(self, state, frame):
        is_alert = (state.fatigue_score >= self.cfg.fatigue_threshold or state.microsleep)
        now = time.time()
        if not is_alert: return
        if now - self._alert_t < self.cfg.alert_cooldown_seconds: return

        self._alert_t = now
        self._alert_n += 1
        level = state.alert_level

        print(f"[ALERT #{self._alert_n}] {level} | Score:{state.fatigue_score:.1%} "
              f"| PERCLOS:{state.perclos:.1%} | Microsleep:{state.microsleep}")

        self.flash.trigger(microsleep=state.microsleep)
        self.audio.play(level)

        if level in ("WARNING","CRITICAL"):
            self.email.send(state)

        self.logger.log(state)
        if self.cfg.screenshots_enabled:
            self.screenshot.save(frame, state)

    # ── Key handling ──────────────────────────────────────────────────────────

    def _handle_key(self, key, display):
        if key in (ord('q'), 27):
            self._running = False
        elif key == ord(' '):   # SPACE = start/stop toggle
            self._toggle_monitoring()
        elif key == ord('s'):
            state = self._cached_state or self.scorer.state
            self.screenshot.save(display, state, manual=True)
        elif key == ord('r'):
            self.scorer.reset()
        elif key == ord('m'):   # toggle mesh
            self.cfg.show_full_mesh = not self.cfg.show_full_mesh
        elif key == ord('i'):   # toggle iris
            self.cfg.show_iris = not self.cfg.show_iris

    def _toggle_monitoring(self):
        if self._state == AppState.STANDBY:
            self._state = AppState.CALIBRATE
            self._calib_t = time.time()
            print("[App] ▶ Calibrating… (30s baseline learning)")
        elif self._state in (AppState.CALIBRATE, AppState.MONITORING):
            self._state = AppState.STANDBY
            print("[App] ■ Monitoring STOPPED (standby)")
        elif self._state == AppState.PAUSED:
            self._state = AppState.MONITORING
            print("[App] ▶ Monitoring RESUMED")

    # ── Banners ───────────────────────────────────────────────────────────────

    def _draw_calibration_banner(self, frame, remaining, state):
        h, w = frame.shape[:2]
        pw = 280
        cx = (w+pw)//2
        bar_w = int((30-remaining)/30 * (w-pw-40))

        # Progress bar
        cv2.rectangle(frame,(pw+20,h-50),(w-20,h-36),(35,38,50),-1)
        cv2.rectangle(frame,(pw+20,h-50),(pw+20+bar_w,h-36),(0,200,120),-1)
        cv2.putText(frame,f"CALIBRATING — learning your baseline EAR… {remaining:.0f}s",
                    (pw+20,h-56),cv2.FONT_HERSHEY_PLAIN,1.1,(0,220,130),1,cv2.LINE_AA)
        cv2.putText(frame,f"Baseline EAR: {state.baseline_ear:.3f}",
                    (pw+20,h-18),cv2.FONT_HERSHEY_PLAIN,1.0,(100,180,100),1,cv2.LINE_AA)

    def _draw_state_banner(self, frame):
        """Small status pill in top-right corner."""
        h, w = frame.shape[:2]
        labels = {
            AppState.STANDBY:    ("STANDBY",    (60,60,80),    (150,150,160)),
            AppState.CALIBRATE:  ("CALIBRATING",(20,80,40),    (0,220,130)),
            AppState.MONITORING: ("MONITORING", (20,60,20),    (0,210,60)),
            AppState.PAUSED:     ("PAUSED",     (60,40,20),    (0,160,220)),
        }
        label, bg, fg = labels.get(self._state, ("?", C_DARK, C_WHITE))
        sz = cv2.getTextSize(label, cv2.FONT_HERSHEY_PLAIN, 1.0, 1)[0]
        x = w - sz[0] - 20; y = 50
        cv2.rectangle(frame,(x-6,y-16),(x+sz[0]+6,y+4),bg,-1)
        cv2.rectangle(frame,(x-6,y-16),(x+sz[0]+6,y+4),fg,1)
        cv2.putText(frame,label,(x,y),cv2.FONT_HERSHEY_PLAIN,1.0,fg,1,cv2.LINE_AA)

    def _empty_state(self):
        from core.fatigue_scorer import FatigueState
        s = FatigueState()
        s.baseline_ear = 0.30
        s.score_trend  = 0.0
        return s

    # ── Shutdown ──────────────────────────────────────────────────────────────

    def _shutdown(self):
        print("\n[App] Shutting down…")
        self._running = False
        self.capture.stop()
        self.detector.release()
        self.logger.session_end(self._alert_n)
        cv2.destroyAllWindows()
        print(f"\n[App] Session complete.")
        print(f"      Alerts fired : {self._alert_n}")
        print(f"      Avg FPS      : {self._fps:.1f}")
        print("      Fly safe. ✈\n")

# missing import fix
C_DARK = (12,16,24)
C_WHITE = (255,255,255)
