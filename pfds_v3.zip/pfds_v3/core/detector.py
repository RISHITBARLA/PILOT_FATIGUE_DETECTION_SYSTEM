"""
Detector — MediaPipe FaceMesh with full 468-point DOT MESH.
Each landmark rendered as a crisp colored dot — clean point cloud look.
Compatible with MediaPipe 0.10+ (Tasks API) and legacy 0.9.x (solutions API).
"""

import cv2
import numpy as np
import mediapipe as mp
from typing import Optional, Tuple, List, NamedTuple
import math
import collections

# ── Landmark indices ──────────────────────────────────────────────────────────
LEFT_EYE_EAR   = [362, 385, 387, 263, 373, 380]
RIGHT_EYE_EAR  = [33,  160, 158, 133, 153, 144]
MOUTH_MAR      = [61,  291,  39, 181,   0,  17, 269, 405]
HEAD_POSE_IDX  = [1, 152, 226, 446, 57, 287]
LEFT_IRIS      = [474, 475, 476, 477]
RIGHT_IRIS     = [469, 470, 471, 472]

FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,
             397,365,379,378,400,377,152,148,176,149,150,136,
             172,58,132,93,234,127,162,21,54,103,67,109,10]

HEAD_3D = np.array([
    (0.0,    0.0,    0.0),
    (0.0,  -330.0, -65.0),
    (-225.0, 170.0,-135.0),
    ( 225.0, 170.0,-135.0),
    (-150.0,-150.0,-125.0),
    ( 150.0,-150.0,-125.0),
], dtype=np.float64)

# ── Zone membership: which landmark indices belong to which facial zone ───────
# These define color of each dot
ZONE_MAP = {}

# Forehead / top (warm amber)
FOREHEAD = list(range(10, 30)) + [108,107,66,105,63,70,156,35,124,46,53,52,65,55]
for i in FOREHEAD: ZONE_MAP[i] = (100, 180, 255)   # amber-white

# Left eye region (cyan)
LEFT_EYE_ZONE = LEFT_EYE_EAR + [384,385,386,387,388,390,398,466,263,249,373,374,380,381,382,362]
for i in LEFT_EYE_ZONE: ZONE_MAP[i] = (255, 220, 50)   # bright cyan

# Right eye region (cyan)
RIGHT_EYE_ZONE = RIGHT_EYE_EAR + [160,159,158,157,173,133,155,154,153,145,144,163,7,33]
for i in RIGHT_EYE_ZONE: ZONE_MAP[i] = (255, 220, 50)

# Nose (green-ish)
NOSE = [1,2,3,4,5,6,168,197,195,196,122,6,19,94,370,462,250,309,438]
for i in NOSE: ZONE_MAP[i] = (80, 220, 100)

# Mouth / lips (soft red)
MOUTH_ZONE = list(MOUTH_MAR) + [13,14,15,16,17,18,200,199,175,152,
                                  78,308,95,88,178,87,14,317,402,
                                  324,318,402,317,14,87,178,88,95]
for i in MOUTH_ZONE: ZONE_MAP[i] = (100, 100, 255)

# Jaw (cool grey-blue)
JAW = [172,136,150,149,176,148,152,377,400,378,379,365,397,288,361,323,454,356,389,251,284,332,297,338,10]
for i in JAW: ZONE_MAP[i] = (180, 160, 130)

# Default (cheeks/rest) — steel blue
DEFAULT_COLOR = (200, 180, 130)


class FaceMetrics(NamedTuple):
    ear: float
    left_ear: float
    right_ear: float
    mar: float
    pitch: float
    yaw: float
    roll: float
    face_detected: bool
    landmarks_2d: Optional[np.ndarray]
    perclos: float
    microsleep: bool
    gaze_x: float
    gaze_y: float
    iris_detected: bool
    eye_closed_frames: int


def _detect_api() -> str:
    try:
        from mediapipe.tasks import python as _t
        from mediapipe.tasks.python import vision as _v
        _ = _v.FaceLandmarker
        return "tasks"
    except Exception:
        pass
    try:
        _ = mp.solutions.face_mesh
        return "solutions"
    except Exception:
        pass
    raise RuntimeError(
        "MediaPipe not working. Run:\n  pip install mediapipe==0.10.14"
    )


class FatigueDetector:
    def __init__(self, config):
        self.cfg = config
        self._api = _detect_api()
        print(f"[Detector] MediaPipe {mp.__version__} — {self._api} API")
        self._init_mp()
        self._cam_matrix: Optional[np.ndarray] = None
        self._dist = np.zeros((4, 1))
        maxlen = int(config.perclos_window_seconds * config.target_fps)
        self._eye_buf = collections.deque(maxlen=maxlen)
        self._consec_closed = 0

    # ── Init ──────────────────────────────────────────────────────────────────

    def _init_mp(self):
        if self._api == "tasks":
            self._init_tasks()
        else:
            self._init_solutions()

    def _init_tasks(self):
        import urllib.request, os
        from mediapipe.tasks import python as mpt
        from mediapipe.tasks.python import vision as mpv
        from mediapipe.tasks.python.core import base_options as bo

        model_path = os.path.join(os.path.dirname(__file__), "face_landmarker.task")
        if not os.path.exists(model_path):
            url = ("https://storage.googleapis.com/mediapipe-models/"
                   "face_landmarker/face_landmarker/float16/1/face_landmarker.task")
            print("[Detector] Downloading face model (~30 MB)…")
            urllib.request.urlretrieve(url, model_path)
            print("[Detector] Model downloaded.")

        opts = mpv.FaceLandmarkerOptions(
            base_options=bo.BaseOptions(model_asset_path=model_path),
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=False,
            num_faces=1,
            min_face_detection_confidence=0.5,
            min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        self._lm = mpv.FaceLandmarker.create_from_options(opts)

    def _init_solutions(self):
        self._fm = mp.solutions.face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,       # enables iris (478 points)
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

    # ── Process ───────────────────────────────────────────────────────────────

    def process_frame(self, frame: np.ndarray) -> Tuple[FaceMetrics, np.ndarray]:
        if self._api == "tasks":
            return self._proc_tasks(frame)
        return self._proc_solutions(frame)

    def _proc_tasks(self, frame):
        h, w = frame.shape[:2]
        ann = frame.copy()
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        res = self._lm.detect(img)
        if not res.face_landmarks:
            return self._no_face(), ann
        lm = np.array([(p.x*w, p.y*h) for p in res.face_landmarks[0]], dtype=np.float32)
        return self._compute(lm, w, h, ann)

    def _proc_solutions(self, frame):
        h, w = frame.shape[:2]
        ann = frame.copy()
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        res = self._fm.process(rgb)
        rgb.flags.writeable = True
        if not res.multi_face_landmarks:
            return self._no_face(), ann
        lm = np.array(
            [(p.x*w, p.y*h) for p in res.multi_face_landmarks[0].landmark],
            dtype=np.float32
        )
        return self._compute(lm, w, h, ann)

    # ── Compute metrics + draw ────────────────────────────────────────────────

    def _compute(self, lm, w, h, ann):
        le  = self._ear(lm, LEFT_EYE_EAR)
        re  = self._ear(lm, RIGHT_EYE_EAR)
        ear = (le + re) / 2.0
        mar = self._mar(lm)
        pitch, yaw, roll = self._pose(lm, w, h)

        closed = ear < self.cfg.ear_threshold
        self._eye_buf.append(1 if closed else 0)
        self._consec_closed = self._consec_closed + 1 if closed else 0

        perclos   = sum(self._eye_buf) / max(len(self._eye_buf), 1)
        microsleep = self._consec_closed >= self.cfg.microsleep_frames
        gx, gy, iris_ok = self._gaze(lm, w, h)

        # Draw the dot mesh
        self._draw_dot_mesh(ann, lm)

        return FaceMetrics(
            ear=ear, left_ear=le, right_ear=re, mar=mar,
            pitch=pitch, yaw=yaw, roll=roll,
            face_detected=True, landmarks_2d=lm,
            perclos=perclos, microsleep=microsleep,
            gaze_x=gx, gaze_y=gy, iris_detected=iris_ok,
            eye_closed_frames=self._consec_closed,
        ), ann

    # ── Drawing — clean dot point cloud ──────────────────────────────────────

    def _draw_dot_mesh(self, frame: np.ndarray, lm: np.ndarray):
        """
        Draw all 468 (or 478 with iris) landmarks as crisp colored dots.
        Color-coded by facial zone. No lines — pure point cloud.
        """
        pts = lm.astype(np.int32)
        dot_r = self.cfg.dot_size   # radius (1 = single pixel dot, 2 = small circle)
        n = min(len(pts), 468)      # first 468 are face landmarks

        for i in range(n):
            x, y = pts[i]
            # Skip off-screen points
            if x < 0 or y < 0 or x >= frame.shape[1] or y >= frame.shape[0]:
                continue
            color = ZONE_MAP.get(i, DEFAULT_COLOR)
            if dot_r <= 1:
                # Single pixel — fastest
                frame[y, x] = color
            else:
                cv2.circle(frame, (x, y), dot_r, color, -1, cv2.LINE_AA)

        # Eye contour dots — slightly larger + brighter to highlight
        if self.cfg.show_contours:
            for idx in LEFT_EYE_EAR + RIGHT_EYE_EAR:
                x, y = pts[idx]
                cv2.circle(frame, (x,y), max(dot_r+1,2), (255, 240, 80), -1, cv2.LINE_AA)

            # Mouth contour dots
            for idx in MOUTH_MAR:
                if idx < len(pts):
                    x, y = pts[idx]
                    cv2.circle(frame, (x,y), max(dot_r+1,2), (120, 100, 255), -1, cv2.LINE_AA)

        # Iris dots — golden ring
        if self.cfg.show_iris and len(lm) >= 478:
            self._draw_iris_dots(frame, lm)

    def _draw_iris_dots(self, frame: np.ndarray, lm: np.ndarray):
        """Draw iris as a small circle with center dot."""
        for iris_idx in [LEFT_IRIS, RIGHT_IRIS]:
            iris_pts = lm[iris_idx]
            cx, cy = iris_pts.mean(axis=0).astype(int)
            r = max(2, int(np.linalg.norm(iris_pts[0] - iris_pts[2]) / 2))
            cv2.circle(frame, (cx, cy), r,   (0, 200, 255), 1, cv2.LINE_AA)
            cv2.circle(frame, (cx, cy), 2,   (0, 240, 255), -1, cv2.LINE_AA)

    def _draw_contours(self, frame: np.ndarray, pts: np.ndarray):
        """Redraw key dots on cached frames (when skipping)."""
        dot_r = max(self.cfg.dot_size, 1)
        n = min(len(pts), 468)
        for i in range(n):
            x, y = pts[i]
            if 0 <= x < frame.shape[1] and 0 <= y < frame.shape[0]:
                color = ZONE_MAP.get(i, DEFAULT_COLOR)
                if dot_r <= 1:
                    frame[y, x] = color
                else:
                    cv2.circle(frame, (x,y), dot_r, color, -1, cv2.LINE_AA)

    # ── Metrics ───────────────────────────────────────────────────────────────

    @staticmethod
    def _ear(lm, idx):
        p = lm[idx]
        v1 = np.linalg.norm(p[1]-p[5])
        v2 = np.linalg.norm(p[2]-p[4])
        h  = np.linalg.norm(p[0]-p[3])
        return (v1+v2)/(2*h) if h > 1e-6 else 0.0

    @staticmethod
    def _mar(lm):
        p = lm[MOUTH_MAR]
        v1 = np.linalg.norm(p[2]-p[6])
        v2 = np.linalg.norm(p[3]-p[5])
        h  = np.linalg.norm(p[0]-p[1])
        return (v1+v2)/(2*h) if h > 1e-6 else 0.0

    def _pose(self, lm, w, h):
        if self._cam_matrix is None:
            self._cam_matrix = np.array(
                [[w,0,w/2],[0,w,h/2],[0,0,1]], dtype=np.float64)
        pts = lm[HEAD_POSE_IDX].astype(np.float64)
        ok, rv, tv = cv2.solvePnP(
            HEAD_3D, pts, self._cam_matrix, self._dist,
            flags=cv2.SOLVEPNP_ITERATIVE
        )
        if not ok: return 0.0, 0.0, 0.0
        rm, _ = cv2.Rodrigues(rv)
        _, _, _, _, _, _, e = cv2.decomposeProjectionMatrix(np.hstack((rm, tv)))
        return float(e[0]), float(e[1]), float(e[2])

    def _gaze(self, lm, w, h):
        if len(lm) < 478:
            return 0.0, 0.0, False
        try:
            li = lm[LEFT_IRIS].mean(axis=0)
            lc = (lm[362] + lm[263]) / 2
            le_w = np.linalg.norm(lm[362]-lm[263])
            ri = lm[RIGHT_IRIS].mean(axis=0)
            rc = (lm[33]+lm[133]) / 2
            re_w = np.linalg.norm(lm[33]-lm[133])
            gx = ((li[0]-lc[0])/le_w + (ri[0]-rc[0])/re_w) / 2
            gy = ((li[1]-lc[1])/le_w + (ri[1]-rc[1])/re_w) / 2
            return float(np.clip(gx*4,-1,1)), float(np.clip(gy*4,-1,1)), True
        except:
            return 0.0, 0.0, False

    def _no_face(self):
        self._consec_closed += 1
        self._eye_buf.append(1)
        perclos = sum(self._eye_buf) / max(len(self._eye_buf), 1)
        return FaceMetrics(
            ear=0.30, left_ear=0.30, right_ear=0.30, mar=0.0,
            pitch=0.0, yaw=0.0, roll=0.0, face_detected=False,
            landmarks_2d=None, perclos=perclos,
            microsleep=self._consec_closed>=self.cfg.microsleep_frames,
            gaze_x=0.0, gaze_y=0.0, iris_detected=False,
            eye_closed_frames=self._consec_closed,
        )

    def release(self):
        if self._api == "tasks" and hasattr(self, "_lm"):
            self._lm.close()
        elif self._api == "solutions" and hasattr(self, "_fm"):
            self._fm.close()
