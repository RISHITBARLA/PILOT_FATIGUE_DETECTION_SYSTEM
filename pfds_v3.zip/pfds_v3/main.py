"""
✈  Pilot Fatigue Detection System v3.0
--------------------------------------
Run: python main.py

Controls:
  SPACE  — Start / Stop monitoring
  Q      — Quit
  S      — Save screenshot
  R      — Reset all counters
  M      — Toggle full mesh on/off
  I      — Toggle iris overlay
"""

import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.config import Config
from core.app import FatigueDetectionApp

def parse():
    p = argparse.ArgumentParser(description="Pilot Fatigue Detection System v3")
    p.add_argument("--camera",     type=int,   default=0,    help="Camera index")
    p.add_argument("--fps",        type=int,   default=30,   help="Target FPS")
    p.add_argument("--threshold",  type=float, default=0.50, help="Fatigue threshold 0-1")
    p.add_argument("--no-audio",   action="store_true")
    p.add_argument("--no-flash",   action="store_true")
    p.add_argument("--log",        action="store_true",      help="Enable CSV logging")
    p.add_argument("--screenshots",action="store_true")
    p.add_argument("--no-mesh",    action="store_true",      help="Disable full mesh")
    p.add_argument("--no-iris",    action="store_true")
    p.add_argument("--skip",       type=int,   default=2,    help="Frame skip (1=every frame)")
    return p.parse_args()

def banner():
    print("""
  ╔══════════════════════════════════════════════════════════════════╗
  ║  ✈   PILOT FATIGUE DETECTION SYSTEM  v3.0                      ║
  ║      AI-Powered Real-Time Drowsiness Monitor                   ║
  ║                                                                 ║
  ║  NEW: Full 468-pt Mesh · Iris Tracking · PERCLOS · Microsleep  ║
  ║       Adaptive Baseline · Gaze Estimation · Session Timer      ║
  ╚══════════════════════════════════════════════════════════════════╝
""")

def main():
    banner()
    args = parse()

    cfg = Config()
    cfg.camera_index        = args.camera
    cfg.target_fps          = args.fps
    cfg.fatigue_threshold   = args.threshold
    cfg.audio_enabled       = not args.no_audio
    cfg.flash_enabled       = not args.no_flash
    cfg.logging_enabled     = args.log
    cfg.screenshots_enabled = args.screenshots
    cfg.show_full_mesh      = not args.no_mesh
    cfg.show_iris           = not args.no_iris
    cfg.skip_frames         = args.skip

    print(f"  Camera      : {cfg.camera_index}")
    print(f"  Target FPS  : {cfg.target_fps}")
    print(f"  Threshold   : {cfg.fatigue_threshold:.0%}")
    print(f"  Full Mesh   : {'ON' if cfg.show_full_mesh else 'OFF'}")
    print(f"  Iris Track  : {'ON' if cfg.show_iris else 'OFF'}")
    print(f"  Audio       : {'ON' if cfg.audio_enabled else 'OFF'}")
    print(f"  Logging     : {'ON' if cfg.logging_enabled else 'OFF'}")
    print()
    print("  ► Press  SPACE  in the video window to START monitoring")
    print("  ► Press  SPACE  again to STOP (e.g. when landed)")
    print("  ► Press  M  to toggle mesh  |  I  to toggle iris")
    print()

    FatigueDetectionApp(cfg).run()

if __name__ == "__main__":
    main()
