"""Save annotated screenshots on fatigue events."""
import cv2, os, numpy as np
from datetime import datetime

class ScreenshotManager:
    def __init__(self, cfg):
        self.cfg = cfg
        self.enabled = cfg.screenshots_enabled
        self._n = 0
        if self.enabled:
            os.makedirs(cfg.screenshots_dir, exist_ok=True)
            print(f"[Screenshots] → ./{cfg.screenshots_dir}/")

    def save(self, frame, state, manual=False):
        if not self.enabled and not manual: return ""
        self._n += 1
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        tag = "MANUAL" if manual else state.alert_level
        path = os.path.join(self.cfg.screenshots_dir, f"{tag}_{ts}.jpg")
        ann = frame.copy()
        h, w = ann.shape[:2]
        ov = ann.copy()
        cv2.rectangle(ov,(0,h-60),(w,h),(0,0,0),-1)
        cv2.addWeighted(ov,0.6,ann,0.4,0,ann)
        cv2.putText(ann,f"PFDS v3 | {ts} | {state.alert_level} | Score:{state.fatigue_score:.1%}",
                    (10,h-38),cv2.FONT_HERSHEY_DUPLEX,0.45,(200,200,200),1,cv2.LINE_AA)
        cv2.putText(ann,f"EAR:{state.ear:.3f} PERCLOS:{state.perclos:.1%} Blink:{state.blink_rate:.2f}/s Pitch:{state.pitch:.1f}deg",
                    (10,h-16),cv2.FONT_HERSHEY_DUPLEX,0.40,(200,200,200),1,cv2.LINE_AA)
        cv2.imwrite(path, ann, [cv2.IMWRITE_JPEG_QUALITY,92])
        print(f"[Screenshot] {path}")
        return path
