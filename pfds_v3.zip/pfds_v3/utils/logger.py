"""CSV + text event logger."""
import os, csv, threading
from datetime import datetime

HEADERS = ["timestamp","level","score","ear","perclos","blink_rate",
           "pitch","yaw","roll","yawns","microsleep","distracted"]

class FatigueLogger:
    def __init__(self, cfg):
        self.cfg = cfg
        self.enabled = cfg.logging_enabled
        self._lock = threading.Lock()
        if not self.enabled: return
        os.makedirs(os.path.dirname(cfg.log_file) or ".", exist_ok=True)
        self._csv = cfg.log_file
        self._txt = cfg.log_file.replace(".csv",".log")
        if not os.path.exists(self._csv):
            with open(self._csv,"w",newline="") as f:
                csv.DictWriter(f,HEADERS).writeheader()
        print(f"[Logger] → {self._csv}")

    def log(self, state):
        if not self.enabled: return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = {"timestamp":ts,"level":state.alert_level,
               "score":f"{state.fatigue_score:.3f}","ear":f"{state.ear:.3f}",
               "perclos":f"{state.perclos:.3f}","blink_rate":f"{state.blink_rate:.3f}",
               "pitch":f"{state.pitch:.1f}","yaw":f"{state.yaw:.1f}","roll":f"{state.roll:.1f}",
               "yawns":state.yawn_count,"microsleep":int(state.microsleep),
               "distracted":int(state.distracted)}
        line = (f"[{ts}] {state.alert_level:8s} score={state.fatigue_score:.1%} "
                f"EAR={state.ear:.3f} PERCLOS={state.perclos:.1%}\n")
        with self._lock:
            with open(self._csv,"a",newline="") as f: csv.DictWriter(f,HEADERS).writerow(row)
            with open(self._txt,"a") as f: f.write(line)

    def session_start(self):
        if not self.enabled: return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            with open(self._txt,"a") as f:
                f.write(f"\n{'='*55}\nSESSION START: {ts}\n{'='*55}\n")

    def session_end(self, n):
        if not self.enabled: return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            with open(self._txt,"a") as f:
                f.write(f"SESSION END: {ts} | Events: {n}\n{'='*55}\n\n")
