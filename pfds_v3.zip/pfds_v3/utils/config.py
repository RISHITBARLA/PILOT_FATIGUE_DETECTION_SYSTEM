"""
Configuration — EXPO MODE: Fast + Efficient + Accurate
Key optimizations:
- 640x480 resolution (2x faster than 1280x720)
- skip_frames=1 (every frame, instant response)
- score_window=8s (fast score reaction)
- calibration=20s (quick warmup)
- mesh_alpha=0.25 (lighter drawing)
"""
from dataclasses import dataclass

@dataclass
class Config:
    # Camera
    camera_index: int = 0
    target_fps: int = 30
    frame_width: int = 640
    frame_height: int = 480
    skip_frames: int = 1

    # EAR
    ear_threshold: float = 0.18
    ear_consec_frames: int = 2
    ear_threshold_ratio: float = 0.60

    # Yawn
    mar_threshold: float = 0.60
    yawn_consec_frames: int = 12

    # Head pose
    head_pitch_threshold: float = 16.0
    head_roll_threshold: float = 20.0
    distraction_yaw_threshold: float = 35.0

    # Neck bend
    neck_bend_pitch_threshold: float = 18.0
    neck_bend_roll_threshold: float = 22.0
    sudden_drop_threshold: float = 8.0

    # Score weights
    weight_ear: float = 0.35
    weight_blink: float = 0.20
    weight_head: float = 0.25
    weight_yawn: float = 0.20
    fatigue_threshold: float = 0.52
    score_window_seconds: int = 8

    # Microsleep
    microsleep_frames: int = 40

    # PERCLOS
    perclos_window_seconds: int = 30
    perclos_threshold: float = 0.18

    # Alerts
    audio_enabled: bool = True
    flash_enabled: bool = True
    alert_cooldown_seconds: int = 5
    flash_duration_frames: int = 30

    # Calibration
    calibration_seconds: int = 20

    # Email
    email_enabled = True
    email_sender = "brishit0406@gmail.com"
    email_password = "YOUR_APP_PASSWORD"  # NOT normal password
    email_recipient = "brishit0406@gmail.com"

    email_smtp_host = "smtp.gmail.com"
    email_smtp_port = 587

    fatigue_threshold = 0.4   # LOWER for testing
    email_cooldown = 10       # seconds
    alert_cooldown_seconds = 5

    # Logging
    logging_enabled: bool = False
    log_file: str = "logs/events.csv"
    screenshots_enabled: bool = False
    screenshots_dir: str = "screenshots"

    # Mesh
    show_full_mesh: bool = True
    show_iris: bool = True
    show_contours: bool = True
    mesh_alpha: float = 0.25
    dot_size: int = 1
